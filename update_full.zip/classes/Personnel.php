<?php
// ============================================
// Personnel: CRUD + mandatory photo handling
// ============================================

require_once __DIR__ . '/../config/db.php';

class Personnel {

    // ---- List / Search ----
    public static function all(): array {
        $db = getDB();
        return $db->query("SELECT p.*, r.name AS rank_name, u.name AS unit_name, b.name AS blood_group_name, a.name AS appointment_name, c.name AS cadre_name, pl.name AS platoon_name, t.name AS trade_name, pf.family_member, pf.living_status, pe.civil_education,
                            (SELECT from_date FROM personnel_leaves WHERE personnel_id = p.id AND CURRENT_DATE >= from_date AND CURRENT_DATE <= to_date LIMIT 1) AS current_leave_from,
                            (SELECT to_date FROM personnel_leaves WHERE personnel_id = p.id AND CURRENT_DATE >= from_date AND CURRENT_DATE <= to_date LIMIT 1) AS current_leave_to
                            FROM personnel p
                            LEFT JOIN ranks r ON p.rank_id = r.id
                            LEFT JOIN units u ON p.unit_id = u.id
                            LEFT JOIN blood_groups b ON p.blood_group_id = b.id
                            LEFT JOIN appointments a ON p.appointment_id = a.id
                            LEFT JOIN cadres c ON p.cadre_id = c.id
                            LEFT JOIN platoons pl ON p.platoon_id = pl.id
                            LEFT JOIN trades t ON p.trade_id = t.id
                            LEFT JOIN personnel_family pf ON p.id = pf.personnel_id
                            LEFT JOIN personnel_education pe ON p.id = pe.personnel_id
                            ORDER BY p.name")->fetchAll();
    }

    public static function filter(array $filters): array {
        $db = getDB();
        $sql = "SELECT p.*, r.name AS rank_name, u.name AS unit_name, b.name AS blood_group_name, a.name AS appointment_name, c.name AS cadre_name, pl.name AS platoon_name, t.name AS trade_name, pf.family_member, pf.living_status, pe.civil_education,
                            (SELECT from_date FROM personnel_leaves WHERE personnel_id = p.id AND CURRENT_DATE >= from_date AND CURRENT_DATE <= to_date LIMIT 1) AS current_leave_from,
                            (SELECT to_date FROM personnel_leaves WHERE personnel_id = p.id AND CURRENT_DATE >= from_date AND CURRENT_DATE <= to_date LIMIT 1) AS current_leave_to
            FROM personnel p
            LEFT JOIN ranks r ON p.rank_id = r.id
            LEFT JOIN units u ON p.unit_id = u.id
            LEFT JOIN blood_groups b ON p.blood_group_id = b.id
            LEFT JOIN appointments a ON p.appointment_id = a.id
            LEFT JOIN cadres c ON p.cadre_id = c.id
            LEFT JOIN platoons pl ON p.platoon_id = pl.id
            LEFT JOIN trades t ON p.trade_id = t.id
            LEFT JOIN personnel_family pf ON p.id = pf.personnel_id
            LEFT JOIN personnel_education pe ON p.id = pe.personnel_id
            WHERE 1=1";
        $params = [];

        $q = trim((string)($filters['q'] ?? ''));
        if ($q !== '') {
            $sql .= " AND (p.name LIKE ? OR p.personal_number LIKE ? OR p.mobile_number LIKE ?)";
            $like = '%' . $q . '%';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $rankId = (int)($filters['rank_id'] ?? 0);
        if ($rankId > 0) {
            $sql .= " AND p.rank_id = ?";
            $params[] = $rankId;
        }

        $unitId = (int)($filters['unit_id'] ?? 0);
        if ($unitId > 0) {
            $sql .= " AND p.unit_id = ?";
            $params[] = $unitId;
        }

        $appointmentId = (int)($filters['appointment_id'] ?? 0);
        if ($appointmentId > 0) {
            $sql .= " AND p.appointment_id = ?";
            $params[] = $appointmentId;
        }

        $tradeId = (int)($filters['trade_id'] ?? 0);
        if ($tradeId > 0) {
            $sql .= " AND p.trade_id = ?";
            $params[] = $tradeId;
        }

        $bloodGroupId = (int)($filters['blood_group_id'] ?? 0);
        if ($bloodGroupId > 0) {
            $sql .= " AND p.blood_group_id = ?";
            $params[] = $bloodGroupId;
        }

        $status = trim((string)($filters['status'] ?? ''));
        if ($status === 'on_leave') {
            $sql .= " AND (p.status = 'on_leave' OR EXISTS (SELECT 1 FROM personnel_leaves pl WHERE pl.personnel_id = p.id AND CURRENT_DATE >= pl.from_date AND CURRENT_DATE <= pl.to_date))";
        } elseif ($status === 'active') {
            $sql .= " AND (p.status = 'active' AND NOT EXISTS (SELECT 1 FROM personnel_leaves pl WHERE pl.personnel_id = p.id AND CURRENT_DATE >= pl.from_date AND CURRENT_DATE <= pl.to_date))";
        } elseif (strpos($status, 'leave_') === 0) {
            $leaveTypeMap = [
                'leave_weekend' => 'Weekend Leave',
                'leave_casual' => 'Casual Leave',
                'leave_pre' => 'Pre Leave',
                'leave_medical' => 'Medical Leave',
                'leave_recreation' => 'Recreation Leave'
            ];
            if (isset($leaveTypeMap[$status])) {
                $sql .= " AND EXISTS (SELECT 1 FROM personnel_leaves pl WHERE pl.personnel_id = p.id AND pl.leave_type = ? AND CURRENT_DATE >= pl.from_date AND CURRENT_DATE <= pl.to_date)";
                $params[] = $leaveTypeMap[$status];
            }
        } elseif ($status !== '') {
            $sql .= " AND p.status = ?";
            $params[] = $status;
        }

        $district = trim((string)($filters['district'] ?? ''));
        if ($district !== '') {
            $sql .= " AND p.address LIKE ?";
            $params[] = '%' . $district . '%';
        }

        $platoonId = (int)($filters['platoon_id'] ?? 0);
        if ($platoonId > 0) {
            $sql .= " AND p.platoon_id = ?";
            $params[] = $platoonId;
        }

        $maritalStatus = trim((string)($filters['marital_status'] ?? ''));
        if ($maritalStatus !== '') {
            $sql .= " AND p.id IN (SELECT personnel_id FROM personnel_family WHERE marital_status = ?)";
            $params[] = $maritalStatus;
        }

        $courseId = (int)($filters['course_id'] ?? 0);
        if ($courseId > 0) {
            $sql .= " AND p.id IN (SELECT personnel_id FROM personnel_courses WHERE course_id = ?)";
            $params[] = $courseId;
        }

        $moqId = (int)($filters['moq_id'] ?? 0);
        $moqStatus = trim((string)($filters['moq_status'] ?? ''));

        if ($moqId > 0) {
            if ($moqStatus === 'qualified' || $moqStatus === 'not_qualified' || $moqStatus === 'not_applicable' || $moqStatus === 'na') {
                $targetIds = self::getPersonnelIdsByIndividualMoq($moqId, $moqStatus);
                if (empty($targetIds)) {
                    $sql .= " AND 1=0";
                } else {
                    $inClause = implode(',', array_map('intval', $targetIds));
                    $sql .= " AND p.id IN ($inClause)";
                }
            } else {
                $targetIds = self::getPersonnelIdsByIndividualMoq($moqId, 'any');
                if (empty($targetIds)) {
                    $sql .= " AND 1=0";
                } else {
                    $inClause = implode(',', array_map('intval', $targetIds));
                    $sql .= " AND p.id IN ($inClause)";
                }
            }
        } elseif ($moqStatus === 'qualified' || $moqStatus === 'not_qualified' || $moqStatus === 'not_applicable' || $moqStatus === 'na') {
            $targetIds = self::getPersonnelIdsByMoqStatus($moqStatus);
            if (empty($targetIds)) {
                $sql .= " AND 1=0";
            } else {
                $inClause = implode(',', array_map('intval', $targetIds));
                $sql .= " AND p.id IN ($inClause)";
            }
        }

        $cadreId = (int)($filters['cadre_id'] ?? 0);
        if ($cadreId > 0) {
            $sql .= " AND (p.cadre_id = ? OR p.id IN (SELECT personnel_id FROM personnel_cadres WHERE cadre_id = ?))";
            $params[] = $cadreId;
            $params[] = $cadreId;
        }

        $familyMember = trim((string)($filters['family_member'] ?? ''));
        if ($familyMember !== '') {
            $sql .= " AND p.id IN (SELECT personnel_id FROM personnel_family WHERE family_member = ?)";
            $params[] = $familyMember;
        }

        $civilEducation = trim((string)($filters['civil_education'] ?? ''));
        if ($civilEducation !== '') {
            if (is_numeric($civilEducation)) {
                $sql .= " AND (pe.civil_education IN (SELECT name FROM civil_educations WHERE id = ?) OR pe.civil_education = ?)";
                $params[] = (int)$civilEducation;
                $params[] = $civilEducation;
            } else {
                if (strcasecmp($civilEducation, 'HSC') === 0) {
                    $sql .= " AND (pe.civil_education = ? OR pe.civil_education IS NULL OR pe.civil_education = '')";
                    $params[] = $civilEducation;
                } else {
                    $sql .= " AND pe.civil_education = ?";
                    $params[] = $civilEducation;
                }
            }
        }

        $sql .= " ORDER BY p.name";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array {
        $db = getDB();
        $stmt = $db->prepare("SELECT p.*, r.name AS rank_name, u.name AS unit_name, c.name AS cadre_name, pl.name AS platoon_name, b.name AS blood_group_name, a.name AS appointment_name, t.name AS trade_name, pe.civil_education,
                       (SELECT leave_type FROM personnel_leaves WHERE personnel_id = p.id AND CURRENT_DATE >= from_date AND CURRENT_DATE <= to_date LIMIT 1) AS current_leave_type
                       FROM personnel p
                       LEFT JOIN ranks r ON p.rank_id = r.id
                       LEFT JOIN units u ON p.unit_id = u.id
                       LEFT JOIN cadres c ON p.cadre_id = c.id
                       LEFT JOIN platoons pl ON p.platoon_id = pl.id
                       LEFT JOIN blood_groups b ON p.blood_group_id = b.id
                       LEFT JOIN appointments a ON p.appointment_id = a.id
                       LEFT JOIN trades t ON p.trade_id = t.id
                       LEFT JOIN personnel_education pe ON p.id = pe.personnel_id
                       WHERE p.id = ?");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function search(string $term): array {
        $db = getDB();
        $stmt = $db->prepare("SELECT p.*, r.name AS rank_name, u.name AS unit_name, a.name AS appointment_name, pf.family_member, pf.living_status, pe.civil_education
                       FROM personnel p
                       LEFT JOIN ranks r ON p.rank_id = r.id
                       LEFT JOIN units u ON p.unit_id = u.id
                       LEFT JOIN appointments a ON p.appointment_id = a.id
                       LEFT JOIN personnel_family pf ON p.id = pf.personnel_id
                       LEFT JOIN personnel_education pe ON p.id = pe.personnel_id
                       WHERE p.name LIKE ? OR p.personal_number LIKE ? OR a.name LIKE ?
                       ORDER BY p.name");
        $like = "%$term%";
        $stmt->execute([$like, $like, $like]);
        return $stmt->fetchAll();
    }

    // ---- Mandatory photo upload/validation ----
    // Returns the saved relative path on success, or throws Exception on failure.
    public static function handlePhotoUpload(array $file, string $personalNumber): string {
        if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
            // Photo is optional now; caller should handle missing photo.
            throw new Exception('NO_PHOTO_UPLOADED');
        }

        if ($file['size'] > MAX_PHOTO_SIZE) {
            throw new Exception('Photo must be smaller than 2MB.');
        }

        // Validate actual MIME type, not just the extension
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png'];
        if (!isset($allowed[$mime])) {
            throw new Exception('Only JPG or PNG photos are allowed.');
        }

        if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);

        $ext = $allowed[$mime];
        $safeNumber = preg_replace('/[^A-Za-z0-9_-]/', '', $personalNumber);
        $filename = $safeNumber . '_' . time() . '.' . $ext;
        $destination = UPLOAD_DIR . $filename;

        // Resize/crop to a consistent 400x400 using GD (bundled with XAMPP)
        self::resizeAndSave($file['tmp_name'], $mime, $destination, 400, 400);

        return $filename; // store just the filename in DB; build full path with UPLOAD_URL
    }

    private static function resizeAndSave(string $srcPath, string $mime, string $destPath, int $w, int $h): void {
        $src = $mime === 'image/png' ? imagecreatefrompng($srcPath) : imagecreatefromjpeg($srcPath);
        if (!$src) {
            throw new Exception('Uploaded image could not be processed.');
        }

        $srcW = imagesx($src);
        $srcH = imagesy($src);

        // Crop to square from center, then resize
        $side = min($srcW, $srcH);
        $srcX = intdiv($srcW - $side, 2);
        $srcY = intdiv($srcH - $side, 2);

        $dst = imagecreatetruecolor($w, $h);
        if ($mime === 'image/png') {
            imagesavealpha($dst, true);
            $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
            imagefill($dst, 0, 0, $transparent);
        }

        imagecopyresampled($dst, $src, 0, 0, $srcX, $srcY, $w, $h, $side, $side);

        if ($mime === 'image/png') {
            imagepng($dst, $destPath, 8);
        } else {
            imagejpeg($dst, $destPath, 85);
        }

        imagedestroy($src);
        imagedestroy($dst);
    }

    // ---- Create ----
    public static function create(array $data, array $photoFile = [], ?array $requesterPerms = null): int {
        $db = getDB();
        $isTransactionOwner = false;
        if (!$db->inTransaction()) {
            $db->beginTransaction();
            $isTransactionOwner = true;
        }

        try {
            // Photo optional: attempt upload only when provided, or use pending photo
            $photoPath = null;
            if (!empty($data['_pending_photo_path'])) {
                $photoPath = $data['_pending_photo_path'];
            } elseif (!empty($photoFile) && isset($photoFile['error']) && $photoFile['error'] === UPLOAD_ERR_OK) {
                try {
                    $photoPath = self::handlePhotoUpload($photoFile, $data['personal_number']); // may throw
                } catch (Exception $e) {
                    if ($e->getMessage() === 'NO_PHOTO_UPLOADED') {
                        $photoPath = null;
                    } else {
                        throw $e;
                    }
                }
            }

            $addressVal = trim((string)($data['address'] ?? '')) ?: null;
            $detailedAddressVal = trim((string)($data['detailed_address'] ?? '')) ?: null;
            $villVal = trim((string)($data['vill'] ?? '')) ?: null;
            $poVal = trim((string)($data['po'] ?? '')) ?: null;
            $psVal = trim((string)($data['ps'] ?? '')) ?: null;

            $tradeId = !empty($data['trade_id']) ? (int)$data['trade_id'] : null;
            if (!$tradeId) {
                try {
                    $stmtGd = $db->query("SELECT id FROM trades WHERE name = 'GD' LIMIT 1");
                    $gdId = $stmtGd ? $stmtGd->fetchColumn() : null;
                    if ($gdId) {
                        $tradeId = (int)$gdId;
                    }
                } catch (Exception $e) {
                }
            }

            $moqNa = (!empty($data['moq_not_applicable']) || !empty($data['moq_na'])) ? 1 : 0;
            $stmt = $db->prepare("INSERT INTO personnel
                (personal_number, name, nid, photo_path, rank_id, trade_id, unit_id, cadre_id, platoon_id, blood_group_id, appointment_id, batch, mobile_number, address, detailed_address, vill, po, ps, status, moq_na)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute([
                $data['personal_number'], $data['name'], trim((string)($data['nid'] ?? '')) ?: null, $photoPath,
                empty($data['rank_id']) ? null : $data['rank_id'], $tradeId, empty($data['unit_id']) ? null : $data['unit_id'], empty($data['cadre_id']) ? null : $data['cadre_id'],
                empty($data['platoon_id']) ? null : $data['platoon_id'], empty($data['blood_group_id']) ? null : $data['blood_group_id'], empty($data['appointment_id']) ? null : $data['appointment_id'],
                trim((string)($data['batch'] ?? '')) ?: null,
                $data['mobile_number'] ?? null, $addressVal, $detailedAddressVal, $villVal, $poVal, $psVal,
                $data['status'] ?? 'active',
                $moqNa
            ]);
            $personnelId = (int)$db->lastInsertId();

            // Save multiple courses (course_id[] and course_result[] expected)
            if (isset($data['course_id']) && is_array($data['course_id'])) {
                self::saveCourse($personnelId, $data['course_id'], $data['course_result'] ?? []);
            } else {
                self::saveCourse($personnelId, $data['course_id'] ?? null, $data['course_result'] ?? null);
            }
            if (isset($data['moq_id']) && is_array($data['moq_id'])) {
                self::saveMoq($personnelId, $data['moq_id'], $data['moq_result'] ?? [], $data['moq_bypass'] ?? []);
            } else {
                self::saveMoq($personnelId, $data['moq_id'] ?? null, $data['moq_result'] ?? null, $data['moq_bypass'] ?? null);
            }
            self::saveEducation($personnelId, $data['civil_education'] ?? null);
            // Save multiple cadres if provided (cadre_ids[])
            if (isset($data['cadre_ids']) && is_array($data['cadre_ids'])) {
                self::saveCadres($personnelId, $data['cadre_ids']);
            } else {
                // fallback single cadre_id
                if (!empty($data['cadre_id'])) {
                    self::saveCadres($personnelId, [(int)$data['cadre_id']]);
                }
            }
            $targetYear = !empty($data['record_year']) ? (int)$data['record_year'] : (!empty($data['service_year']) ? (int)$data['service_year'] : (int)date('Y'));
            self::saveService($personnelId, $data['admission_date'] ?? null, $data['retirement_date'] ?? null, $data['un_mission'] ?? null, $data['punishment_note'] ?? null, $data['ipft_1st'] ?? null, $data['ipft_2nd'] ?? null, $data['ret'] ?? null, $data['speed_march'] ?? null, $data['cycle_1'] ?? null, $data['cycle_2'] ?? null, $data['cycle_3'] ?? null, $data['cycle_4'] ?? null, $targetYear);
            self::saveFamily(
                $personnelId,
                $data['birthdate'] ?? null,
                $data['marriage_date'] ?? null,
                $data['father_name'] ?? null,
                $data['father_mobile'] ?? null,
                $data['mother_name'] ?? null,
                $data['mother_mobile'] ?? null,
                $data['spouse_name'] ?? null,
                $data['spouse_mobile'] ?? null,
                $data['children_count'] ?? null,
                $data['marital_status'] ?? null,
                $data['family_member'] ?? 'No',
                $data['living_status'] ?? null,
                $data['fm_date_from'] ?? null,
                $data['fm_date_to'] ?? null,
                $data['fm_current_address'] ?? null
            );
            self::saveHealth($personnelId, empty($data['medical_category_id']) ? null : (int)$data['medical_category_id'], $data['height_cm'] ?? null, $data['weight_kg'] ?? null, $data['any_disease'] ?? null);
            self::saveSocialLinks($personnelId, $data['social_links'] ?? []);
            self::saveNote($personnelId, $data['special_note'] ?? null);
            if (isset($data['leaves']) && is_array($data['leaves'])) {
                self::saveLeaves($personnelId, $data['leaves']);
            }

            if ($isTransactionOwner) $db->commit();
            return $personnelId;
        } catch (Exception $e) {
            if ($isTransactionOwner) $db->rollBack();
            if (!empty($photoPath ?? '')) {
                @unlink(UPLOAD_DIR . $photoPath);
            }
            throw $e;
        }
    }

    private static function hasPerm(string $perm, ?array $requesterPerms): bool {
        if ($requesterPerms !== null) {
            return in_array($perm, $requesterPerms);
        }
        return Auth::hasPermission($perm);
    }

    public static function hasAnyPerm(array $requiredPerms, ?array $userPerms = null): bool {
        if ($userPerms !== null) {
            return !empty(array_intersect($requiredPerms, $userPerms));
        }
        return Auth::hasAnyPermission($requiredPerms);
    }

    private static function parseCommaSeparatedLookups(string $table, string $str): array {
        $ids = [];
        foreach (explode(',', $str) as $val) {
            $val = trim($val);
            if ($val !== '') {
                $ids[] = (string)self::getOrCreateLookup($table, $val);
            }
        }
        return $ids;
    }

    private static function parseKeyValueLookups(string $table, string $str): array {
        $ids = [];
        $results = [];
        foreach (explode(',', $str) as $item) {
            $parts = explode(':', $item, 2);
            $name = trim($parts[0]);
            if ($name !== '') {
                $id = (string)self::getOrCreateLookup($table, $name);
                $ids[] = $id;
                $results[$id] = trim($parts[1] ?? '');
            }
        }
        return ['ids' => $ids, 'results' => $results];
    }

    private static function parseLeaves(string $str): array {
        $leaves = ['from_date' => [], 'to_date' => [], 'leave_type' => []];
        foreach (explode(',', $str) as $item) {
            $parts = explode(':', $item, 3);
            if (count($parts) >= 2) {
                $leaves['from_date'][] = trim($parts[0]);
                $leaves['to_date'][] = trim($parts[1]);
                $leaves['leave_type'][] = trim($parts[2] ?? '');
            }
        }
        return $leaves;
    }

    private static function parseSocialLinks(string $str): array {
        $links = [];
        foreach (explode(',', $str) as $item) {
            // Because URL contains ':' (e.g. https://), we limit explode to 2.
            $parts = explode(':', $item, 2);
            $platform = strtolower(trim($parts[0]));
            $url = trim($parts[1] ?? '');
            if ($platform !== '' && $url !== '') {
                $links[$platform] = $url;
            }
        }
        return $links;
    }

    // ---- Update (photo optional on edit — keep existing if not replaced) ----
    public static function update(int $id, array $data, ?array $photoFile = null, ?array $requesterPerms = null): void {
        $db = getDB();
        $isTransactionOwner = false;
        if (!$db->inTransaction()) {
            $db->beginTransaction();
            $isTransactionOwner = true;
        }
        $existingPerson = self::find($id);
        $oldPhotoPath = $existingPerson['photo_path'] ?? null;
        $newPhotoPath = null;

        if (!$existingPerson) {
            throw new Exception("Personnel not found.");
        }

        try {
            $newPhotoPath = null;

            $addressVal = $data['address'] ?? null;
            $detailedAddressVal = $data['detailed_address'] ?? null;
            $villVal = $data['vill'] ?? null;
            $poVal = $data['po'] ?? null;
            $psVal = $data['ps'] ?? null;

            if (self::hasPerm('edit_personnel_basic', $requesterPerms)) {
                if ($photoFile && $photoFile['error'] === UPLOAD_ERR_OK) {
                    $newPhotoPath = self::handlePhotoUpload($photoFile, $data['personal_number'] ?? $existingPerson['personal_number']);
                    // Delete old photo
                    if (!empty($existingPerson['photo_path'])) {
                        $oldPath = UPLOAD_DIR . $existingPerson['photo_path'];
                        if (file_exists($oldPath) && is_file($oldPath)) {
                            unlink($oldPath);
                        }
                    }
                }
                
                $sql = "UPDATE personnel SET personal_number=?, name=?, nid=?, rank_id=?, trade_id=?, unit_id=?,
                        cadre_id=?, platoon_id=?, blood_group_id=?, appointment_id=?, batch=?, mobile_number=?, address=?, detailed_address=?, vill=?, po=?, ps=?, status=?";
                $params = [
                    $data['personal_number'] ?? $existingPerson['personal_number'], $data['name'] ?? $existingPerson['name'], trim((string)($data['nid'] ?? $existingPerson['nid'])) ?: null,
                    empty($data['rank_id']) ? null : $data['rank_id'], empty($data['trade_id']) ? null : $data['trade_id'], empty($data['unit_id']) ? null : $data['unit_id'], empty($data['cadre_id']) ? null : $data['cadre_id'],
                    empty($data['platoon_id']) ? null : $data['platoon_id'], empty($data['blood_group_id']) ? null : $data['blood_group_id'], empty($data['appointment_id']) ? null : $data['appointment_id'],
                    trim((string)($data['batch'] ?? '')) ?: null,
                    $data['mobile_number'] ?? null, $addressVal, $detailedAddressVal, $villVal, $poVal, $psVal,
                    $data['status'] ?? 'active'
                ];

                if ($newPhotoPath) {
                    $sql .= ", photo_path=?";
                    $params[] = $newPhotoPath;
                }
                
                $sql .= " WHERE id=?";
                $params[] = $id;

                $stmt = $db->prepare($sql);
                $stmt->execute($params);

            } elseif (self::hasPerm('edit_personnel_status', $requesterPerms) && isset($data['status'])) {
                $stmt = $db->prepare("UPDATE personnel SET status=? WHERE id=?");
                $stmt->execute([$data['status'], $id]);
            }

            // Removed clearRelatedData() to handle it per section
            if (self::hasPerm('edit_personnel_course', $requesterPerms)) {
                $db->prepare("DELETE FROM personnel_courses WHERE personnel_id = ?")->execute([$id]);
                if (isset($data['course_id']) && is_array($data['course_id'])) {
                    self::saveCourse($id, $data['course_id'], $data['course_result'] ?? []);
                } else {
                    self::saveCourse($id, $data['course_id'] ?? null, $data['course_result'] ?? null);
                }
            }

            if (self::hasPerm('edit_personnel_moqs', $requesterPerms)) {
                $moqNa = (!empty($data['moq_not_applicable']) || !empty($data['moq_na'])) ? 1 : 0;
                $db->prepare("UPDATE personnel SET moq_na = ? WHERE id = ?")->execute([$moqNa, $id]);

                $db->prepare("DELETE FROM personnel_moqs WHERE personnel_id = ?")->execute([$id]);
                if (isset($data['moq_id']) && is_array($data['moq_id'])) {
                    self::saveMoq($id, $data['moq_id'], $data['moq_result'] ?? [], $data['moq_bypass'] ?? []);
                } else {
                    self::saveMoq($id, $data['moq_id'] ?? null, $data['moq_result'] ?? null, $data['moq_bypass'] ?? null);
                }
            }

            if (self::hasPerm('edit_personnel_cadres', $requesterPerms)) {
                $db->prepare("DELETE FROM personnel_cadres WHERE personnel_id = ?")->execute([$id]);
                if (isset($data['cadre_ids']) && is_array($data['cadre_ids'])) {
                    self::saveCadres($id, $data['cadre_ids']);
                } else {
                    if (!empty($data['cadre_id'])) {
                        self::saveCadres($id, [(int)$data['cadre_id']]);
                    }
                }
            }

            if (self::hasPerm('edit_personnel_education', $requesterPerms)) {
                $db->prepare("DELETE FROM personnel_education WHERE personnel_id = ?")->execute([$id]);
                self::saveEducation($id, $data['civil_education'] ?? null);
            }

            $targetYear = !empty($data['record_year']) ? (int)$data['record_year'] : (!empty($data['service_year']) ? (int)$data['service_year'] : (int)date('Y'));
            $updateService = false;
            $existingService = self::getService($id, $targetYear) ?: [];
            $serviceData = [
                'admission_date' => $existingService['admission_date'] ?? null,
                'retirement_date' => $existingService['retirement_date'] ?? null,
                'un_mission' => $existingService['un_mission'] ?? null,
                'punishment_note' => $existingService['punishment_note'] ?? null,
                'ipft_1st' => $existingService['ipft_1st'] ?? null,
                'ipft_2nd' => $existingService['ipft_2nd'] ?? null,
                'ret' => $existingService['ret'] ?? null,
                'speed_march' => $existingService['speed_march'] ?? null,
                'cycle_1' => $existingService['cycle_1'] ?? null,
                'cycle_2' => $existingService['cycle_2'] ?? null,
                'cycle_3' => $existingService['cycle_3'] ?? null,
                'cycle_4' => $existingService['cycle_4'] ?? null,
            ];

            if (self::hasPerm('edit_personnel_service', $requesterPerms)) {
                $serviceData['admission_date'] = $data['admission_date'] ?? null;
                $serviceData['retirement_date'] = $data['retirement_date'] ?? null;
                $serviceData['un_mission'] = $data['un_mission'] ?? null;
                $serviceData['punishment_note'] = $data['punishment_note'] ?? null;
                $updateService = true;
            }
            if (self::hasPerm('edit_personnel_ipft', $requesterPerms)) {
                $serviceData['ipft_1st'] = $data['ipft_1st'] ?? null;
                $serviceData['ipft_2nd'] = $data['ipft_2nd'] ?? null;
                $serviceData['ret'] = $data['ret'] ?? null;
                $serviceData['speed_march'] = $data['speed_march'] ?? null;
                $updateService = true;
            }
            if (self::hasPerm('edit_personnel_yearly_plan', $requesterPerms)) {
                $serviceData['cycle_1'] = $data['cycle_1'] ?? null;
                $serviceData['cycle_2'] = $data['cycle_2'] ?? null;
                $serviceData['cycle_3'] = $data['cycle_3'] ?? null;
                $serviceData['cycle_4'] = $data['cycle_4'] ?? null;
                $updateService = true;
            }

            if ($updateService) {
                self::saveService(
                    $id,
                    $serviceData['admission_date'],
                    $serviceData['retirement_date'],
                    $serviceData['un_mission'],
                    $serviceData['punishment_note'],
                    $serviceData['ipft_1st'],
                    $serviceData['ipft_2nd'],
                    $serviceData['ret'],
                    $serviceData['speed_march'],
                    $serviceData['cycle_1'],
                    $serviceData['cycle_2'],
                    $serviceData['cycle_3'],
                    $serviceData['cycle_4'],
                    $targetYear
                );
            }

            $updateFamily = false;
            $existingFamily = self::getFamily($id) ?: [];
            $familyData = [
                'birthdate' => $existingFamily['birthdate'] ?? null,
                'marriage_date' => $existingFamily['marriage_date'] ?? null,
                'father_name' => $existingFamily['father_name'] ?? null,
                'father_mobile' => $existingFamily['father_mobile'] ?? null,
                'mother_name' => $existingFamily['mother_name'] ?? null,
                'mother_mobile' => $existingFamily['mother_mobile'] ?? null,
                'spouse_name' => $existingFamily['spouse_name'] ?? null,
                'spouse_mobile' => $existingFamily['spouse_mobile'] ?? null,
                'children_count' => $existingFamily['children_count'] ?? null,
                'marital_status' => $existingFamily['marital_status'] ?? null,
                'family_member' => $existingFamily['family_member'] ?? 'No',
                'living_status' => $existingFamily['living_status'] ?? null,
                'fm_date_from' => $existingFamily['fm_date_from'] ?? null,
                'fm_date_to' => $existingFamily['fm_date_to'] ?? null,
                'fm_current_address' => $existingFamily['fm_current_address'] ?? null,
            ];

            if (self::hasPerm('edit_personnel_family', $requesterPerms)) {
                $familyData['birthdate'] = $data['birthdate'] ?? null;
                $familyData['marriage_date'] = $data['marriage_date'] ?? null;
                $familyData['father_name'] = $data['father_name'] ?? null;
                $familyData['father_mobile'] = $data['father_mobile'] ?? null;
                $familyData['mother_name'] = $data['mother_name'] ?? null;
                $familyData['mother_mobile'] = $data['mother_mobile'] ?? null;
                $familyData['spouse_name'] = $data['spouse_name'] ?? null;
                $familyData['spouse_mobile'] = $data['spouse_mobile'] ?? null;
                $familyData['children_count'] = $data['children_count'] ?? null;
                $familyData['marital_status'] = $data['marital_status'] ?? null;
                $updateFamily = true;
            }

            if (self::hasPerm('edit_personnel_family_member_status', $requesterPerms)) {
                $familyData['family_member'] = $data['family_member'] ?? 'No';
                $familyData['living_status'] = $data['living_status'] ?? null;
                $familyData['fm_date_from'] = $data['fm_date_from'] ?? null;
                $familyData['fm_date_to'] = $data['fm_date_to'] ?? null;
                $familyData['fm_current_address'] = $data['fm_current_address'] ?? null;
                $updateFamily = true;
            }

            if ($updateFamily) {
                self::saveFamily(
                    $id,
                    $familyData['birthdate'],
                    $familyData['marriage_date'],
                    $familyData['father_name'],
                    $familyData['father_mobile'],
                    $familyData['mother_name'],
                    $familyData['mother_mobile'],
                    $familyData['spouse_name'],
                    $familyData['spouse_mobile'],
                    $familyData['children_count'],
                    $familyData['marital_status'],
                    $familyData['family_member'],
                    $familyData['living_status'],
                    $familyData['fm_date_from'],
                    $familyData['fm_date_to'],
                    $familyData['fm_current_address']
                );
            }

            if (self::hasPerm('edit_personnel_health', $requesterPerms)) {
                $db->prepare("DELETE FROM personnel_health WHERE personnel_id = ?")->execute([$id]);
                self::saveHealth($id, empty($data['medical_category_id']) ? null : (int)$data['medical_category_id'], $data['height_cm'] ?? null, $data['weight_kg'] ?? null, $data['any_disease'] ?? null);
            }

            if (self::hasPerm('edit_personnel_social', $requesterPerms)) {
                $db->prepare("DELETE FROM personnel_social_links WHERE personnel_id = ?")->execute([$id]);
                self::saveSocialLinks($id, $data['social_links'] ?? []);
            }

            if (self::hasPerm('edit_personnel_notes', $requesterPerms)) {
                $db->prepare("DELETE FROM personnel_notes WHERE personnel_id = ?")->execute([$id]);
                self::saveNote($id, $data['special_note'] ?? null);
            }

            if (self::hasPerm('edit_personnel_leaves', $requesterPerms)) {
                self::saveLeaves($id, $data['leaves'] ?? []);
            }

            if ($isTransactionOwner) $db->commit();
            if (!empty($newPhotoPath) && !empty($oldPhotoPath) && $oldPhotoPath !== $newPhotoPath) {
                $oldFile = UPLOAD_DIR . $oldPhotoPath;
                if (is_file($oldFile)) {
                    @unlink($oldFile);
                }
            }
        } catch (Exception $e) {
            if ($isTransactionOwner) $db->rollBack();
            if (!empty($newPhotoPath)) {
                $newFile = UPLOAD_DIR . $newPhotoPath;
                if (is_file($newFile)) {
                    @unlink($newFile);
                }
            }
            throw $e;
        }
    }



    private static function saveCourse(int $personnelId, $courseIdOrArray, $resultOrArray = null): void {
        $db = getDB();
        // support single course or arrays
        if (is_array($courseIdOrArray)) {
            $courseIds = $courseIdOrArray;
            $results = is_array($resultOrArray) ? $resultOrArray : [];
            $isSequential = empty($results) || (array_keys($results) === range(0, count($results) - 1));
            $stmt = $db->prepare("INSERT INTO personnel_courses (personnel_id, course_id, result) VALUES (?,?,?)");
            foreach ($courseIds as $idx => $cid) {
                $cid = (int)$cid;
                if ($cid <= 0) continue;
                if (isset($results[$cid]) && !$isSequential) {
                    $res = $results[$cid];
                } elseif (isset($results[$idx]) && $isSequential) {
                    $res = $results[$idx];
                } else {
                    $res = $results[$cid] ?? ($results[$idx] ?? null);
                }
                $stmt->execute([$personnelId, $cid, trim($res) ?: null]);
            }
            return;
        }

        // single
        $courseId = $courseIdOrArray;
        $result = $resultOrArray;
        if (!$courseId) return;
        $stmt = $db->prepare("INSERT INTO personnel_courses (personnel_id, course_id, result) VALUES (?,?,?)");
        $stmt->execute([$personnelId, $courseId, $result ?: null]);
    }

    private static function saveMoq(int $personnelId, $moqIdOrArray, $resultOrArray = null, $bypassOrArray = null): void {
        $db = getDB();
        // support single moq or arrays
        if (is_array($moqIdOrArray)) {
            $moqIds = $moqIdOrArray;
            $results = is_array($resultOrArray) ? $resultOrArray : [];
            $bypasses = is_array($bypassOrArray) ? $bypassOrArray : [];
            $isSequential = empty($results) || (array_keys($results) === range(0, count($results) - 1));
            $stmt = $db->prepare("INSERT INTO personnel_moqs (personnel_id, moq_id, result, is_bypass) VALUES (?,?,?,?)");
            foreach ($moqIds as $idx => $cid) {
                $cid = (int)$cid;
                if ($cid <= 0) continue;
                if (isset($results[$cid]) && !$isSequential) {
                    $res = $results[$cid];
                } elseif (isset($results[$idx]) && $isSequential) {
                    $res = $results[$idx];
                } else {
                    $res = $results[$cid] ?? ($results[$idx] ?? null);
                }
                $isBypass = !empty($bypasses[$cid]) || !empty($bypasses[$idx]) || (is_string($res) && strtolower(trim($res)) === 'bypass') ? 1 : 0;
                $stmt->execute([$personnelId, $cid, trim((string)$res) ?: ($isBypass ? 'Bypass' : null), $isBypass]);
            }
            return;
        }

        // single
        $moqId = (int)$moqIdOrArray;
        $result = $resultOrArray;
        if (!$moqId) return;
        $isBypass = !empty($bypassOrArray) || (is_string($result) && strtolower(trim($result)) === 'bypass') ? 1 : 0;
        $stmt = $db->prepare("INSERT INTO personnel_moqs (personnel_id, moq_id, result, is_bypass) VALUES (?,?,?,?)");
        $stmt->execute([$personnelId, $moqId, $result ?: ($isBypass ? 'Bypass' : null), $isBypass]);
    }

    private static function saveCadres(int $personnelId, array $cadreIds): void {
        if (empty($cadreIds)) return;
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO personnel_cadres (personnel_id, cadre_id) VALUES (?,?)");
        foreach ($cadreIds as $cid) {
            $cid = (int)$cid;
            if ($cid <= 0) continue;
            $stmt->execute([$personnelId, $cid]);
        }
    }

    public static function getCadres(int $personnelId): array {
        $db = getDB();
        $stmt = $db->prepare("SELECT c.* FROM personnel_cadres pc JOIN cadres c ON pc.cadre_id = c.id WHERE pc.personnel_id = ? ORDER BY c.name");
        $stmt->execute([$personnelId]);
        return $stmt->fetchAll();
    }

    public static function getCourses(int $personnelId): array {
        $db = getDB();
        $stmt = $db->prepare("SELECT pc.*, c.name AS course_name FROM personnel_courses pc JOIN courses c ON pc.course_id = c.id WHERE pc.personnel_id = ? ORDER BY pc.id");
        $stmt->execute([$personnelId]);
        return $stmt->fetchAll();
    }

    public static function getMoqs(int $personnelId): array {
        $db = getDB();
        $stmt = $db->prepare("SELECT pm.*, m.name AS moq_name FROM personnel_moqs pm JOIN moqs m ON pm.moq_id = m.id WHERE pm.personnel_id = ? ORDER BY pm.id");
        $stmt->execute([$personnelId]);
        return $stmt->fetchAll();
    }

    private static function saveEducation(int $personnelId, ?string $civilEducation): void {
        $edu = trim((string)$civilEducation);
        if ($edu === '') {
            $edu = 'HSC';
        }
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO personnel_education (personnel_id, civil_education) VALUES (?,?)");
        $stmt->execute([$personnelId, $edu]);
    }

    public static function saveService(int $personnelId, ?string $admissionDate, ?string $retirementDate, ?string $unMission, ?string $punishmentNote, ?string $ipft1 = null, ?string $ipft2 = null, ?string $ret = null, ?string $speedMarch = null, ?string $c1 = null, ?string $c2 = null, ?string $c3 = null, ?string $c4 = null, ?int $year = null): void {
        $year = $year ?: (int)date('Y');
        $hasCareer = ($admissionDate !== null && trim($admissionDate) !== '')
            || ($retirementDate !== null && trim($retirementDate) !== '')
            || ($unMission !== null && trim($unMission) !== '')
            || ($punishmentNote !== null && trim($punishmentNote) !== '');

        $hasAnnual = ($ipft1 !== null && trim((string)$ipft1) !== '')
            || ($ipft2 !== null && trim((string)$ipft2) !== '')
            || ($ret !== null && trim((string)$ret) !== '')
            || ($speedMarch !== null && trim((string)$speedMarch) !== '')
            || ($c1 !== null && trim((string)$c1) !== '')
            || ($c2 !== null && trim((string)$c2) !== '')
            || ($c3 !== null && trim((string)$c3) !== '')
            || ($c4 !== null && trim((string)$c4) !== '');

        // 1. Save annual performance to personnel_yearly_records
        self::saveYearlyRecord($personnelId, $year, [
            'ipft_1st' => $ipft1,
            'ipft_2nd' => $ipft2,
            'ret' => $ret,
            'speed_march' => $speedMarch,
            'cycle_1' => $c1,
            'cycle_2' => $c2,
            'cycle_3' => $c3,
            'cycle_4' => $c4,
        ]);

        if (!$hasCareer && !$hasAnnual) {
            return;
        }

        $db = getDB();
        $currentYear = (int)date('Y');
        $isCurrentYear = ($year === $currentYear);

        $stmt = $db->prepare("SELECT id FROM personnel_service WHERE personnel_id = ? LIMIT 1");
        $stmt->execute([$personnelId]);
        $existing = $stmt->fetch();

        if ($existing) {
            if ($isCurrentYear) {
                $upd = $db->prepare("UPDATE personnel_service SET 
                    admission_date = ?, retirement_date = ?, un_mission = ?, punishment_note = ?,
                    service_year = ?, ipft_1st = ?, ipft_2nd = ?, ret = ?, speed_march = ?,
                    cycle_1 = ?, cycle_2 = ?, cycle_3 = ?, cycle_4 = ?
                    WHERE id = ?");
                $upd->execute([
                    $admissionDate ?: null,
                    $retirementDate ?: null,
                    trim((string)$unMission) ?: null,
                    trim((string)$punishmentNote) ?: null,
                    $currentYear,
                    trim((string)$ipft1) ?: null,
                    trim((string)$ipft2) ?: null,
                    trim((string)$ret) ?: null,
                    trim((string)$speedMarch) ?: null,
                    trim((string)$c1) ?: null,
                    trim((string)$c2) ?: null,
                    trim((string)$c3) ?: null,
                    trim((string)$c4) ?: null,
                    $existing['id']
                ]);
            } else {
                $upd = $db->prepare("UPDATE personnel_service SET 
                    admission_date = ?, retirement_date = ?, un_mission = ?, punishment_note = ?
                    WHERE id = ?");
                $upd->execute([
                    $admissionDate ?: null,
                    $retirementDate ?: null,
                    trim((string)$unMission) ?: null,
                    trim((string)$punishmentNote) ?: null,
                    $existing['id']
                ]);
            }
        } else {
            $ins = $db->prepare("INSERT INTO personnel_service (
                personnel_id, service_year, admission_date, retirement_date, un_mission, punishment_note,
                ipft_1st, ipft_2nd, ret, speed_march, cycle_1, cycle_2, cycle_3, cycle_4
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $ins->execute([
                $personnelId,
                $isCurrentYear ? $currentYear : null,
                $admissionDate ?: null,
                $retirementDate ?: null,
                trim((string)$unMission) ?: null,
                trim((string)$punishmentNote) ?: null,
                $isCurrentYear ? (trim((string)$ipft1) ?: null) : null,
                $isCurrentYear ? (trim((string)$ipft2) ?: null) : null,
                $isCurrentYear ? (trim((string)$ret) ?: null) : null,
                $isCurrentYear ? (trim((string)$speedMarch) ?: null) : null,
                $isCurrentYear ? (trim((string)$c1) ?: null) : null,
                $isCurrentYear ? (trim((string)$c2) ?: null) : null,
                $isCurrentYear ? (trim((string)$c3) ?: null) : null,
                $isCurrentYear ? (trim((string)$c4) ?: null) : null,
            ]);
        }
    }

    private static function saveFamily(int $personnelId, ?string $birthdate, ?string $marriageDate, ?string $fatherName, ?string $fatherMobile, ?string $motherName, ?string $motherMobile, ?string $spouseName, ?string $spouseMobile, ?string $childrenCount, ?string $maritalStatus, ?string $familyMember, ?string $livingStatus, ?string $fmDateFrom = null, ?string $fmDateTo = null, ?string $fmCurrentAddress = null): void {
        // If everything is empty, skip saving
        if ((($birthdate === null || trim($birthdate) === '') && ($marriageDate === null || trim($marriageDate) === '') && ($fatherName === null || trim($fatherName) === '') && ($fatherMobile === null || trim($fatherMobile) === '') && ($motherName === null || trim($motherName) === '') && ($motherMobile === null || trim($motherMobile) === '') && ($spouseName === null || trim($spouseName) === '') && ($spouseMobile === null || trim($spouseMobile) === '') && ($childrenCount === null || trim($childrenCount) === '') && ($maritalStatus === null || trim($maritalStatus) === '') && ($familyMember === null || trim($familyMember) === 'No') && ($livingStatus === null || trim($livingStatus) === '') && ($fmDateFrom === null || trim($fmDateFrom) === '') && ($fmDateTo === null || trim($fmDateTo) === '') && ($fmCurrentAddress === null || trim($fmCurrentAddress) === '')) ) {
            return;
        }
        $db = getDB();
        // check if exists
        $stmt = $db->prepare("SELECT id FROM personnel_family WHERE personnel_id = :pid");
        $stmt->execute([':pid' => $personnelId]);
        if ($row = $stmt->fetch()) {
            $stmt = $db->prepare('UPDATE personnel_family SET birthdate = :b, marriage_date = :m, father_name = :fn, father_mobile = :fm, mother_name = :mn, mother_mobile = :mm, spouse_name = :sn, spouse_mobile = :sm, children_count = :c, marital_status = :ms, family_member = :fm_mb, fm_date_from = :fdf, fm_date_to = :fdt, fm_current_address = :fca, living_status = :ls WHERE personnel_id = :pid');
            $stmt->execute([
                ':b' => $birthdate ?: null,
                ':m' => $marriageDate ?: null,
                ':fn' => trim($fatherName) ?: null,
                ':fm' => trim($fatherMobile) ?: null,
                ':mn' => trim($motherName) ?: null,
                ':mm' => trim($motherMobile) ?: null,
                ':sn' => trim($spouseName) ?: null,
                ':sm' => trim($spouseMobile) ?: null,
                ':c' => $childrenCount !== null && trim($childrenCount) !== '' ? (int)$childrenCount : 0,
                ':ms' => $maritalStatus ?: null,
                ':fm_mb' => $familyMember ?: 'No',
                ':fdf' => trim($fmDateFrom) ?: null,
                ':fdt' => trim($fmDateTo) ?: null,
                ':fca' => trim($fmCurrentAddress) ?: null,
                ':ls' => trim($livingStatus) ?: null,
                ':pid' => $personnelId
            ]);
        } else {
            $stmt = $db->prepare('INSERT INTO personnel_family (personnel_id, birthdate, marriage_date, father_name, father_mobile, mother_name, mother_mobile, spouse_name, spouse_mobile, children_count, marital_status, family_member, fm_date_from, fm_date_to, fm_current_address, living_status) VALUES (:pid, :b, :m, :fn, :fm, :mn, :mm, :sn, :sm, :c, :ms, :fm_mb, :fdf, :fdt, :fca, :ls)');
            $stmt->execute([
                ':pid' => $personnelId,
                ':b' => $birthdate ?: null,
                ':m' => $marriageDate ?: null,
                ':fn' => trim($fatherName) ?: null,
                ':fm' => trim($fatherMobile) ?: null,
                ':mn' => trim($motherName) ?: null,
                ':mm' => trim($motherMobile) ?: null,
                ':sn' => trim($spouseName) ?: null,
                ':sm' => trim($spouseMobile) ?: null,
                ':c' => $childrenCount !== null && trim($childrenCount) !== '' ? (int)$childrenCount : 0,
                ':ms' => $maritalStatus ?: null,
                ':fm_mb' => $familyMember ?: 'No',
                ':fdf' => trim($fmDateFrom) ?: null,
                ':fdt' => trim($fmDateTo) ?: null,
                ':fca' => trim($fmCurrentAddress) ?: null,
                ':ls' => trim($livingStatus) ?: null
            ]);
        }
    }

    private static function saveHealth(int $personnelId, ?int $medicalCategoryId, ?string $height, ?string $weight, ?string $anyDisease): void {
        if (($medicalCategoryId === null || $medicalCategoryId === 0) && ($height === null || trim($height) === '') && ($weight === null || trim($weight) === '') && ($anyDisease === null || trim($anyDisease) === '')) {
            return;
        }
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO personnel_health (personnel_id, medical_category_id, height_cm, weight_kg, any_disease) VALUES (?,?,?,?,?)");
        $stmt->execute([
            $personnelId,
            $medicalCategoryId ?: null,
            $height !== null && trim($height) !== '' ? $height : null,
            $weight !== null && trim($weight) !== '' ? $weight : null,
            trim($anyDisease) ?: null
        ]);
    }

    private static function saveSocialLinks(int $personnelId, array $links): void {
        $db = getDB();
        foreach ($links as $platform => $url) {
            $url = trim($url);
            if ($url === '') {
                continue;
            }
            if ($platform === 'whatsapp') {
                if (strpos($url, 'https://wa.me/') !== 0 && strpos($url, 'http') !== 0) {
                    $url = 'https://wa.me/' . preg_replace('/[^0-9+]/', '', $url);
                }
            }
            $stmt = $db->prepare("INSERT INTO personnel_social_links (personnel_id, platform, url) VALUES (?,?,?)");
            $stmt->execute([$personnelId, $platform, $url]);
        }
    }

    private static function saveNote(int $personnelId, ?string $note): void {
        if ($note === null || trim($note) === '') {
            return;
        }
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO personnel_notes (personnel_id, note) VALUES (?,?)");
        $stmt->execute([$personnelId, trim($note)]);
    }

    public static function getCourse(int $personnelId): ?array {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM personnel_courses WHERE personnel_id = ? LIMIT 1");
        $stmt->execute([$personnelId]);
        return $stmt->fetch() ?: null;
    }

    public static function getMoq(int $personnelId): ?array {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM personnel_moqs WHERE personnel_id = ? LIMIT 1");
        $stmt->execute([$personnelId]);
        return $stmt->fetch() ?: null;
    }

    public static function getEducation(int $personnelId): ?array {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM personnel_education WHERE personnel_id = ? LIMIT 1");
        $stmt->execute([$personnelId]);
        return $stmt->fetch() ?: null;
    }

    public static function ensureYearlyRollover(): void {
        static $checked = false;
        if ($checked) return;
        $checked = true;

        $currentYear = (int)date('Y');
        $db = getDB();

        try {
            // Find records where service_year is set and is less than current year
            $stmt = $db->prepare("SELECT * FROM personnel_service WHERE service_year IS NOT NULL AND service_year < ?");
            $stmt->execute([$currentYear]);
            $oldRecords = $stmt->fetchAll();

            if (!empty($oldRecords)) {
                $insertYearly = $db->prepare("
                    INSERT INTO personnel_yearly_records 
                    (personnel_id, record_year, ipft_1st, ipft_2nd, ret, speed_march, cycle_1, cycle_2, cycle_3, cycle_4)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE 
                        ipft_1st = VALUES(ipft_1st), ipft_2nd = VALUES(ipft_2nd), ret = VALUES(ret),
                        speed_march = VALUES(speed_march), cycle_1 = VALUES(cycle_1), cycle_2 = VALUES(cycle_2),
                        cycle_3 = VALUES(cycle_3), cycle_4 = VALUES(cycle_4)
                ");

                $updateService = $db->prepare("
                    UPDATE personnel_service 
                    SET ipft_1st = ?, ipft_2nd = ?, ret = ?, speed_march = ?,
                        cycle_1 = ?, cycle_2 = ?, cycle_3 = ?, cycle_4 = ?,
                        service_year = ?
                    WHERE id = ?
                ");

                foreach ($oldRecords as $rec) {
                    $insertYearly->execute([
                        $rec['personnel_id'],
                        $rec['service_year'],
                        $rec['ipft_1st'],
                        $rec['ipft_2nd'],
                        $rec['ret'],
                        $rec['speed_march'],
                        $rec['cycle_1'],
                        $rec['cycle_2'],
                        $rec['cycle_3'],
                        $rec['cycle_4']
                    ]);

                    $currStmt = $db->prepare("SELECT * FROM personnel_yearly_records WHERE personnel_id = ? AND record_year = ? LIMIT 1");
                    $currStmt->execute([$rec['personnel_id'], $currentYear]);
                    $curr = $currStmt->fetch();

                    if ($curr) {
                        $updateService->execute([
                            $curr['ipft_1st'], $curr['ipft_2nd'], $curr['ret'], $curr['speed_march'],
                            $curr['cycle_1'], $curr['cycle_2'], $curr['cycle_3'], $curr['cycle_4'],
                            $currentYear, $rec['id']
                        ]);
                    } else {
                        $updateService->execute([
                            null, null, null, null,
                            null, null, null, null,
                            $currentYear, $rec['id']
                        ]);
                    }
                }
            }
        } catch (\Throwable $e) {
            // Ignore if table not yet initialized
        }
    }

    public static function saveYearlyRecord(int $personnelId, int $year, array $data): void {
        $db = getDB();
        $ipft1 = trim((string)($data['ipft_1st'] ?? '')) ?: null;
        $ipft2 = trim((string)($data['ipft_2nd'] ?? '')) ?: null;
        $ret = trim((string)($data['ret'] ?? '')) ?: null;
        $speedMarch = trim((string)($data['speed_march'] ?? '')) ?: null;
        $c1 = trim((string)($data['cycle_1'] ?? '')) ?: null;
        $c2 = trim((string)($data['cycle_2'] ?? '')) ?: null;
        $c3 = trim((string)($data['cycle_3'] ?? '')) ?: null;
        $c4 = trim((string)($data['cycle_4'] ?? '')) ?: null;

        $hasAny = ($ipft1 !== null || $ipft2 !== null || $ret !== null || $speedMarch !== null || $c1 !== null || $c2 !== null || $c3 !== null || $c4 !== null);

        if ($hasAny) {
            $stmt = $db->prepare("
                INSERT INTO personnel_yearly_records 
                (personnel_id, record_year, ipft_1st, ipft_2nd, ret, speed_march, cycle_1, cycle_2, cycle_3, cycle_4)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    ipft_1st = VALUES(ipft_1st), ipft_2nd = VALUES(ipft_2nd), ret = VALUES(ret),
                    speed_march = VALUES(speed_march), cycle_1 = VALUES(cycle_1), cycle_2 = VALUES(cycle_2),
                    cycle_3 = VALUES(cycle_3), cycle_4 = VALUES(cycle_4)
            ");
            $stmt->execute([$personnelId, $year, $ipft1, $ipft2, $ret, $speedMarch, $c1, $c2, $c3, $c4]);
        } else {
            $stmt = $db->prepare("DELETE FROM personnel_yearly_records WHERE personnel_id = ? AND record_year = ?");
            $stmt->execute([$personnelId, $year]);
        }

        $currentYear = (int)date('Y');
        if ($year === $currentYear) {
            $check = $db->prepare("SELECT id FROM personnel_service WHERE personnel_id = ? LIMIT 1");
            $check->execute([$personnelId]);
            $existingService = $check->fetch();

            if ($existingService) {
                $upd = $db->prepare("
                    UPDATE personnel_service 
                    SET ipft_1st = ?, ipft_2nd = ?, ret = ?, speed_march = ?,
                        cycle_1 = ?, cycle_2 = ?, cycle_3 = ?, cycle_4 = ?,
                        service_year = ?
                    WHERE personnel_id = ?
                ");
                $upd->execute([$ipft1, $ipft2, $ret, $speedMarch, $c1, $c2, $c3, $c4, $currentYear, $personnelId]);
            }
        }
    }

    public static function getYearlyHistory(int $personnelId): array {
        self::ensureYearlyRollover();
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM personnel_yearly_records WHERE personnel_id = ? ORDER BY record_year DESC");
        $stmt->execute([$personnelId]);
        return $stmt->fetchAll() ?: [];
    }

    public static function getYearlyRecord(int $personnelId, int $year): ?array {
        self::ensureYearlyRollover();
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM personnel_yearly_records WHERE personnel_id = ? AND record_year = ? LIMIT 1");
        $stmt->execute([$personnelId, $year]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function resetYearlyRecord(int $personnelId, int $year): void {
        $db = getDB();
        $stmt = $db->prepare("DELETE FROM personnel_yearly_records WHERE personnel_id = ? AND record_year = ?");
        $stmt->execute([$personnelId, $year]);

        if ($year === (int)date('Y')) {
            $stmt = $db->prepare("
                UPDATE personnel_service 
                SET ipft_1st = NULL, ipft_2nd = NULL, ret = NULL, speed_march = NULL,
                    cycle_1 = NULL, cycle_2 = NULL, cycle_3 = NULL, cycle_4 = NULL
                WHERE personnel_id = ?
            ");
            $stmt->execute([$personnelId]);
        }
    }

    public static function resetAllYearlyRecords(int $year): void {
        $db = getDB();
        $stmt = $db->prepare("DELETE FROM personnel_yearly_records WHERE record_year = ?");
        $stmt->execute([$year]);

        if ($year === (int)date('Y')) {
            $db->exec("
                UPDATE personnel_service 
                SET ipft_1st = NULL, ipft_2nd = NULL, ret = NULL, speed_march = NULL,
                    cycle_1 = NULL, cycle_2 = NULL, cycle_3 = NULL, cycle_4 = NULL
            ");
        }
    }

    public static function getService(int $personnelId, ?int $year = null): ?array {
        $db = getDB();
        $targetYear = $year ?: (int)date('Y');
        self::ensureYearlyRollover();

        $stmt = $db->prepare("SELECT * FROM personnel_service WHERE personnel_id = ? LIMIT 1");
        $stmt->execute([$personnelId]);
        $service = $stmt->fetch();

        $yrStmt = $db->prepare("SELECT * FROM personnel_yearly_records WHERE personnel_id = ? AND record_year = ? LIMIT 1");
        $yrStmt->execute([$personnelId, $targetYear]);
        $yearly = $yrStmt->fetch();

        if (!$service && !$yearly) {
            return null;
        }

        if (!$service) {
            $service = [
                'personnel_id' => $personnelId,
                'admission_date' => null,
                'retirement_date' => null,
                'un_mission' => null,
                'punishment_note' => null,
            ];
        }

        $service['record_year'] = $targetYear;
        $service['service_year'] = $targetYear;

        if ($yearly) {
            $service['ipft_1st'] = $yearly['ipft_1st'];
            $service['ipft_2nd'] = $yearly['ipft_2nd'];
            $service['ret'] = $yearly['ret'];
            $service['speed_march'] = $yearly['speed_march'];
            $service['cycle_1'] = $yearly['cycle_1'];
            $service['cycle_2'] = $yearly['cycle_2'];
            $service['cycle_3'] = $yearly['cycle_3'];
            $service['cycle_4'] = $yearly['cycle_4'];
        } else {
            $service['ipft_1st'] = null;
            $service['ipft_2nd'] = null;
            $service['ret'] = null;
            $service['speed_march'] = null;
            $service['cycle_1'] = null;
            $service['cycle_2'] = null;
            $service['cycle_3'] = null;
            $service['cycle_4'] = null;
        }

        return $service;
    }

    public static function getFamily(int $personnelId): ?array {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM personnel_family WHERE personnel_id = ? LIMIT 1");
        $stmt->execute([$personnelId]);
        return $stmt->fetch() ?: null;
    }

    public static function getHealth(int $personnelId): ?array {
        $db = getDB();
        $stmt = $db->prepare("SELECT ph.*, mc.name AS medical_category_name
                              FROM personnel_health ph
                              LEFT JOIN medical_categories mc ON ph.medical_category_id = mc.id
                              WHERE ph.personnel_id = ?
                              LIMIT 1");
        $stmt->execute([$personnelId]);
        return $stmt->fetch() ?: null;
    }

    public static function getNotes(int $personnelId): ?array {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM personnel_notes WHERE personnel_id = ? ORDER BY created_at DESC LIMIT 1");
        $stmt->execute([$personnelId]);
        return $stmt->fetch() ?: null;
    }

    public static function getSocialLinks(int $personnelId): array {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM personnel_social_links WHERE personnel_id = ? ORDER BY id");
        $stmt->execute([$personnelId]);
        return $stmt->fetchAll();
    }

    public static function getLeaves(int $personnelId): array {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM personnel_leaves WHERE personnel_id = ? ORDER BY from_date DESC");
        $stmt->execute([$personnelId]);
        return $stmt->fetchAll();
    }

    private static function saveLeaves(int $personnelId, array $leavesData): void {
        $db = getDB();
        $stmt = $db->prepare("DELETE FROM personnel_leaves WHERE personnel_id = ?");
        $stmt->execute([$personnelId]);

        if (empty($leavesData['from_date'])) return;

        $stmt = $db->prepare("INSERT INTO personnel_leaves (personnel_id, from_date, to_date, total_days, leave_type) VALUES (?, ?, ?, ?, ?)");
        
        $count = count($leavesData['from_date']);
        for ($i = 0; $i < $count; $i++) {
            $from = trim((string)($leavesData['from_date'][$i] ?? ''));
            $to = trim((string)($leavesData['to_date'][$i] ?? ''));
            $days = trim((string)($leavesData['total_days'][$i] ?? ''));
            $type = trim((string)($leavesData['leave_type'][$i] ?? ''));
            
            if ($from === '' && $to === '' && $type === '') continue;
            
            $stmt->execute([$personnelId, $from ?: null, $to ?: null, $days !== '' ? (int)$days : null, $type ?: null]);
        }
    }

    // ---- Delete ----
    public static function delete(int $id): void {
        $person = self::find($id);
        if ($person && !empty($person['photo_path'])) {
            $file = UPLOAD_DIR . $person['photo_path'];
            if (file_exists($file)) unlink($file);
        }
        $db = getDB();
        $stmt = $db->prepare("DELETE FROM personnel WHERE id = ?");
        $stmt->execute([$id]);
    }
    
    public static function parseExcelForPreview(string $filePath): array {
        require_once __DIR__ . '/../vendor/autoload.php';
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($filePath);
        $sheet = $spreadsheet->getActiveSheet();
        
        $results = [];
        
        foreach ($sheet->getRowIterator(2) as $rowObj) {
            $rowIndex = $rowObj->getRowIndex();
            $personalNumber = trim((string)$sheet->getCell('A' . $rowIndex)->getValue());
            $name = trim((string)$sheet->getCell('B' . $rowIndex)->getValue());
            
            if ($personalNumber === '' && $name === '') {
                continue; // Skip empty rows
            }
            if ($personalNumber === '') {
                $results[] = ['row' => $rowIndex, 'status' => 'error', 'message' => 'Personal Number is required'];
                continue;
            }
            if ($name === '') {
                $results[] = ['row' => $rowIndex, 'personal_number' => $personalNumber, 'status' => 'error', 'message' => 'Name is required'];
                continue;
            }
            
            try {
                $data = [
                    'personal_number' => $personalNumber,
                    'name' => $name,
                    'nid' => trim((string)$sheet->getCell('C' . $rowIndex)->getValue()),
                    'appointment_id' => self::getOrCreateLookup('appointments', $sheet->getCell('D' . $rowIndex)->getValue()),
                    'rank_id' => self::getOrCreateLookup('ranks', $sheet->getCell('E' . $rowIndex)->getValue()),
                    'unit_id' => self::getOrCreateLookup('units', $sheet->getCell('F' . $rowIndex)->getValue()),
                    'platoon_id' => self::getOrCreateLookup('platoons', $sheet->getCell('G' . $rowIndex)->getValue()),
                    'blood_group_id' => self::getOrCreateLookup('blood_groups', $sheet->getCell('H' . $rowIndex)->getValue()),
                    'status' => trim((string)$sheet->getCell('I' . $rowIndex)->getValue()) ?: 'active',
                    'batch' => trim((string)$sheet->getCell('J' . $rowIndex)->getValue()),
                    'mobile_number' => trim((string)$sheet->getCell('K' . $rowIndex)->getValue()),
                    'address' => trim((string)$sheet->getCell('L' . $rowIndex)->getValue()), // district
                    'vill' => trim((string)$sheet->getCell('M' . $rowIndex)->getValue()),
                    'po' => trim((string)$sheet->getCell('N' . $rowIndex)->getValue()),
                    'ps' => trim((string)$sheet->getCell('O' . $rowIndex)->getValue()),
                    'admission_date' => self::parseExcelDate($sheet->getCell('P' . $rowIndex)),
                    'retirement_date' => self::parseExcelDate($sheet->getCell('Q' . $rowIndex)),
                    'un_mission' => trim((string)$sheet->getCell('R' . $rowIndex)->getValue()),
                    'punishment_note' => trim((string)$sheet->getCell('S' . $rowIndex)->getValue()),
                    'ipft_1st' => trim((string)$sheet->getCell('T' . $rowIndex)->getValue()),
                    'ipft_2nd' => trim((string)$sheet->getCell('U' . $rowIndex)->getValue()),
                    'ret' => trim((string)$sheet->getCell('V' . $rowIndex)->getValue()),
                    'speed_march' => trim((string)$sheet->getCell('W' . $rowIndex)->getValue()),
                    'cycle_1' => trim((string)$sheet->getCell('X' . $rowIndex)->getValue()),
                    'cycle_2' => trim((string)$sheet->getCell('Y' . $rowIndex)->getValue()),
                    'cycle_3' => trim((string)$sheet->getCell('Z' . $rowIndex)->getValue()),
                    'cycle_4' => trim((string)$sheet->getCell('AA' . $rowIndex)->getValue()),
                    'birthdate' => self::parseExcelDate($sheet->getCell('AB' . $rowIndex)),
                    'marriage_date' => self::parseExcelDate($sheet->getCell('AC' . $rowIndex)),
                    'marital_status' => trim(strtolower((string)$sheet->getCell('AD' . $rowIndex)->getValue())),
                    'children_count' => trim((string)$sheet->getCell('AE' . $rowIndex)->getValue()),
                    'family_member' => trim((string)$sheet->getCell('AF' . $rowIndex)->getValue()) ?: 'No',
                    'fm_date_from' => self::parseExcelDate($sheet->getCell('AG' . $rowIndex)),
                    'fm_date_to' => self::parseExcelDate($sheet->getCell('AH' . $rowIndex)),
                    'living_status' => trim((string)$sheet->getCell('AI' . $rowIndex)->getValue()),
                    'fm_current_address' => trim((string)$sheet->getCell('AJ' . $rowIndex)->getValue()),
                    'father_name' => trim((string)$sheet->getCell('AK' . $rowIndex)->getValue()),
                    'father_mobile' => trim((string)$sheet->getCell('AL' . $rowIndex)->getValue()),
                    'mother_name' => trim((string)$sheet->getCell('AM' . $rowIndex)->getValue()),
                    'mother_mobile' => trim((string)$sheet->getCell('AN' . $rowIndex)->getValue()),
                    'spouse_name' => trim((string)$sheet->getCell('AO' . $rowIndex)->getValue()),
                    'spouse_mobile' => trim((string)$sheet->getCell('AP' . $rowIndex)->getValue()),
                    'medical_category_id' => self::getOrCreateLookup('medical_categories', $sheet->getCell('AQ' . $rowIndex)->getValue()),
                    'height_cm' => trim((string)$sheet->getCell('AR' . $rowIndex)->getValue()),
                    'weight_kg' => trim((string)$sheet->getCell('AS' . $rowIndex)->getValue()),
                    'any_disease' => trim((string)$sheet->getCell('AT' . $rowIndex)->getValue()),
                    'special_note' => trim((string)$sheet->getCell('AU' . $rowIndex)->getValue()),
                ];

                $cadresStr = trim((string)$sheet->getCell('AV' . $rowIndex)->getValue());
                if ($cadresStr !== '') {
                    $data['cadre_ids'] = self::parseCommaSeparatedLookups('cadres', $cadresStr);
                }
                
                $coursesStr = trim((string)$sheet->getCell('AW' . $rowIndex)->getValue());
                if ($coursesStr !== '') {
                    $cData = self::parseKeyValueLookups('courses', $coursesStr);
                    $data['course_id'] = $cData['ids'];
                    $data['course_result'] = $cData['results'];
                }
                
                $moqsStr = trim((string)$sheet->getCell('AX' . $rowIndex)->getValue());
                if ($moqsStr !== '') {
                    $mData = self::parseKeyValueLookups('moqs', $moqsStr);
                    $data['moq_id'] = $mData['ids'];
                    $data['moq_result'] = $mData['results'];
                }
                
                $leavesStr = trim((string)$sheet->getCell('AY' . $rowIndex)->getValue());
                if ($leavesStr !== '') {
                    $data['leaves'] = self::parseLeaves($leavesStr);
                }
                
                $socialStr = trim((string)$sheet->getCell('AZ' . $rowIndex)->getValue());
                if ($socialStr !== '') {
                    $data['social_links'] = self::parseSocialLinks($socialStr);
                }
                
                $db = getDB();
                $stmt = $db->prepare("SELECT id FROM personnel WHERE personal_number = ?");
                $stmt->execute([$personalNumber]);
                $id = $stmt->fetchColumn();

                $results[] = [
                    'row' => $rowIndex,
                    'personal_number' => $personalNumber,
                    'name' => $name,
                    'status' => 'success',
                    'message' => $id ? 'Will update existing record' : 'Will create new record',
                    'data' => $data,
                    'rank_id' => $data['rank_id'],
                    'unit_id' => $data['unit_id']
                ];
            } catch (Exception $e) {
                $results[] = ['row' => $rowIndex, 'personal_number' => $personalNumber, 'name' => $name, 'status' => 'error', 'message' => $e->getMessage()];
            }
        }
        
        return $results;
    }
    
    public static function saveImportData(array $rows): array {
        $results = [];
        $perms = ['edit_personnel_basic', 'edit_personnel_status', 'edit_personnel_course', 'edit_personnel_moqs', 'edit_personnel_cadres', 'edit_personnel_education', 'edit_personnel_service', 'edit_personnel_ipft', 'edit_personnel_yearly_plan', 'edit_personnel_family', 'edit_personnel_family_member_status', 'edit_personnel_health', 'edit_personnel_social', 'edit_personnel_notes', 'edit_personnel_leaves'];

        foreach ($rows as $item) {
            if ($item['status'] === 'error') {
                $results[] = $item;
                continue;
            }
            try {
                $data = $item['data'];
                $personalNumber = $data['personal_number'];
                $name = $data['name'];
                
                $db = getDB();
                $stmt = $db->prepare("SELECT id FROM personnel WHERE personal_number = ?");
                $stmt->execute([$personalNumber]);
                $id = $stmt->fetchColumn();
                
                if ($id) {
                    self::update((int)$id, $data, null, $perms);
                    $results[] = ['row' => $item['row'], 'personal_number' => $personalNumber, 'name' => $name, 'status' => 'success', 'message' => 'Updated existing record'];
                } else {
                    self::create($data, [], $perms);
                    $results[] = ['row' => $item['row'], 'personal_number' => $personalNumber, 'name' => $name, 'status' => 'success', 'message' => 'Created new record'];
                }
            } catch (Exception $e) {
                $results[] = ['row' => $item['row'] ?? '-', 'personal_number' => $item['personal_number'] ?? '-', 'name' => $item['name'] ?? '-', 'status' => 'error', 'message' => $e->getMessage()];
            }
        }
        return $results;
    }

    
    private static function parseExcelDate($cell): ?string {
        $val = $cell->getValue();
        if ($val === null || trim((string)$val) === '') return null;
        if (\PhpOffice\PhpSpreadsheet\Shared\Date::isDateTime($cell)) {
            $timestamp = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToTimestamp($val);
            return gmdate('Y-m-d', $timestamp);
        }
        $time = strtotime((string)$val);
        return $time ? date('Y-m-d', $time) : null;
    }

    private static function getOrCreateLookup(string $table, $value): ?int {
        $allowed = ['ranks', 'units', 'cadres', 'platoons', 'blood_groups', 'courses', 'moqs', 'medical_categories', 'appointments', 'trades'];
        if (!in_array($table, $allowed, true)) {
            throw new \InvalidArgumentException("Invalid lookup table: $table");
        }
        if ($value === null || trim((string)$value) === '') return null;
        $value = trim((string)$value);
        $db = getDB();
        $stmt = $db->prepare("SELECT id FROM `$table` WHERE name = ?");
        $stmt->execute([$value]);
        $id = $stmt->fetchColumn();
        if ($id) return (int)$id;
        
        try {
            $stmt = $db->prepare("INSERT INTO `$table` (name) VALUES (?)");
            $stmt->execute([$value]);
            return (int)$db->lastInsertId();
        } catch (Exception $e) {
            return null;
        }
    }

    /**
     * Check promotion qualification for a given rank and personnel training items.
     *
     * @param string|null $rankName
     * @param array<int, array<string, mixed>> $moqs
     * @param array<int, array<string, mixed>> $courses
     * @param array<int, array<string, mixed>> $cadres
     * @param bool $isMoqNa
     * @param string|null $civilEducation
     * @return array{has_logic: bool, is_qualified: bool, canonical_rank: ?string, missing: string[], completed: string[], is_na?: bool, status?: string, status_label?: string}
     */
    public static function checkPromotionStatus(?string $rankName, array $moqs = [], array $courses = [], array $cadres = [], bool $isMoqNa = false, ?string $civilEducation = null): array {
        if ($isMoqNa) {
            return [
                'has_logic' => false,
                'is_qualified' => false,
                'is_na' => true,
                'status' => 'not_applicable',
                'status_label' => 'Not Applicable',
                'canonical_rank' => null,
                'missing' => [],
                'completed' => []
            ];
        }
        $rawRank = strtolower(trim((string)$rankName));
        if ($rawRank === '') {
            return [
                'has_logic' => false,
                'is_qualified' => false,
                'canonical_rank' => null,
                'missing' => [],
                'completed' => []
            ];
        }

        $canonicalRank = match (true) {
            in_array($rawRank, ['sainik', 'snk', 'snk(gd)', 'snk (gd)', 'soldier', 'snk.'], true) || str_starts_with($rawRank, 'snk') => 'sainik',
            in_array($rawRank, ['lance corporal', 'lcpl', 'l/cpl', 'l.cpl', 'l cpl', 'l-cpl'], true) || str_starts_with($rawRank, 'lcpl') || str_starts_with($rawRank, 'l/cpl') => 'lance corporal',
            in_array($rawRank, ['corporal', 'cpl', 'cpl.'], true) || str_starts_with($rawRank, 'cpl') => 'corporal',
            in_array($rawRank, ['sergeant', 'sgt', 'sgt.'], true) || str_starts_with($rawRank, 'sgt') => 'sergeant',
            in_array($rawRank, ['warrant officer', 'wo', 'wo.', 'swo', 'senior warrant officer', 'mwo', 'master warrant officer'], true) || $rawRank === 'wo' || str_starts_with($rawRank, 'wo ') || str_starts_with($rawRank, 'swo') || str_starts_with($rawRank, 'mwo') => 'warrant officer',
            default => null,
        };

        if ($canonicalRank === null) {
            return [
                'has_logic' => false,
                'is_qualified' => false,
                'canonical_rank' => null,
                'missing' => [],
                'completed' => []
            ];
        }

        $isFailed = static function (?string $result): bool {
            if ($result === null) {
                return false;
            }
            $r = strtolower(trim($result));
            return in_array($r, ['fail', 'failed', 'f', 'unsuccessful', 'not qualified', 'disqualified', 'dropped'], true);
        };

        $validEntries = [];
        $validCourses = [];
        foreach ($moqs as $m) {
            $name = trim((string)($m['moq_name'] ?? $m['name'] ?? ''));
            $res = $m['result'] ?? null;
            $isBypassed = !empty($m['is_bypass']) || (is_string($res) && strtolower(trim($res)) === 'bypass');
            if ($name !== '' && ($isBypassed || !$isFailed($res))) {
                $validEntries[] = strtolower($name);
            }
        }
        foreach ($courses as $c) {
            $name = trim((string)($c['course_name'] ?? $c['name'] ?? ''));
            $res = $c['result'] ?? null;
            if ($name !== '' && !$isFailed($res)) {
                $lowerName = strtolower($name);
                $validEntries[] = $lowerName;
                $validCourses[] = $lowerName;
            }
        }
        foreach ($cadres as $cd) {
            $name = trim((string)($cd['cadre_name'] ?? $cd['name'] ?? ''));
            if ($name !== '') {
                $validEntries[] = strtolower($name);
            }
        }

        // Bypassed MOQs automatically count as completed/waived for all personnel
        $bypassedMoqs = self::getBypassedMoqs();
        foreach ($bypassedMoqs as $bMoqName) {
            $bName = strtolower(trim((string)$bMoqName));
            if ($bName !== '') {
                $validEntries[] = $bName;
            }
        }

        $hasItem = static function (array $patterns) use ($validEntries): bool {
            foreach ($validEntries as $entry) {
                foreach ($patterns as $p) {
                    $patternLower = strtolower($p);
                    if ($entry === $patternLower) {
                        return true;
                    }
                    if (preg_match('/\b' . preg_quote($patternLower, '/') . '\b/i', $entry) === 1) {
                        return true;
                    }
                }
            }
            return false;
        };

        $missing = [];
        $completed = [];

        if ($canonicalRank === 'sainik') {
            if ($hasItem(['btt', 'basic trade training'])) {
                $completed[] = 'BTT';
            } else {
                $missing[] = 'BTT';
            }

            if ($hasItem(['arms commando', 'services commando', 'commando'])) {
                $completed[] = 'Arms Commando or Services Commando';
            } else {
                $missing[] = 'Arms Commando or Services Commando';
            }

            if ($hasItem(['bmr', 'basic military refresher'])) {
                $completed[] = 'BMR';
            } else {
                $missing[] = 'BMR';
            }

            if ($hasItem(['pe', 'promotion exam', 'promotion examination', 'physical efficiency'])) {
                $completed[] = 'PE';
            } else {
                $missing[] = 'PE';
            }
        } elseif ($canonicalRank === 'lance corporal') {
            if ($hasItem(['pc', 'potential cadre'])) {
                $completed[] = 'PC';
            } else {
                $missing[] = 'PC';
            }

            if ($hasItem(['pe', 'promotion exam', 'promotion examination', 'physical efficiency'])) {
                $completed[] = 'PE';
            } else {
                $missing[] = 'PE';
            }
        } elseif ($canonicalRank === 'corporal') {
            if ($hasItem(['att', 'advance trade training', 'advanced trade training'])) {
                $completed[] = 'ATT';
            } else {
                $missing[] = 'ATT';
            }

            if ($hasItem(['pe', 'promotion exam', 'promotion examination', 'physical efficiency'])) {
                $completed[] = 'PE';
            } else {
                $missing[] = 'PE';
            }
        } elseif ($canonicalRank === 'sergeant') {
            $ncocMatches = ['ncoc', 'non-commissioned officers course', 'non commissioned officers course'];
            $ncocAdvMatches = ["nco's advanced", "nco’s advanced", "nco advanced", "ncos advanced"];
            $hasNcoc = $hasItem($ncocMatches) || $hasItem($ncocAdvMatches);

            if ($hasNcoc) {
                $completed[] = 'NCOC';
            } else {
                $missing[] = 'NCOC';
            }

            // SGT with any course does not need MOQ Utility Course; also explicit Utility Course/MOQ accepted
            $hasUtility = $hasItem(['utility course', 'utility']);

            $hasNonNcocCourse = false;
            foreach ($validCourses as $cName) {
                $isNcoc = false;
                foreach ($ncocMatches as $p) {
                    if ($cName === $p || str_contains($cName, $p)) {
                        $isNcoc = true;
                        break;
                    }
                }
                if (!$isNcoc) {
                    $hasNonNcocCourse = true;
                    break;
                }
            }

            $ncocInCourses = false;
            foreach ($validCourses as $cName) {
                foreach ($ncocMatches as $p) {
                    if ($cName === $p || str_contains($cName, $p)) {
                        $ncocInCourses = true;
                        break 2;
                    }
                }
            }

            $hasCourseForUtility = $hasUtility || $hasNonNcocCourse || (!$ncocInCourses && !empty($validCourses));

            if ($hasCourseForUtility) {
                $completed[] = 'Utility Course';
            } else {
                $missing[] = 'Utility Course';
            }

            if ($hasItem(['pe', 'promotion exam', 'promotion examination', 'physical efficiency'])) {
                $completed[] = 'PE';
            } else {
                $missing[] = 'PE';
            }
        } elseif ($canonicalRank === 'warrant officer') {
            if ($hasItem(['clm cadre', 'clm', 'jcoc', 'junior command', 'junior commissioned'])) {
                $completed[] = 'CLM Cadre or JCOC';
            } else {
                $missing[] = 'CLM Cadre or JCOC';
            }

            if ($hasItem(['pe', 'promotion exam', 'promotion examination', 'physical efficiency'])) {
                $completed[] = 'PE';
            } else {
                $missing[] = 'PE';
            }
        }

        $edu = trim((string)$civilEducation);
        if ($edu === '') {
            $edu = 'HSC';
        }
        $isSsc = (strtoupper($edu) === 'SSC') || (preg_match('/\bSSC\b/i', $edu) === 1);
        if ($isSsc) {
            $missing[] = 'HSC required (has SSC)';
        } else {
            $completed[] = 'Civil Education: ' . $edu;
        }

        return [
            'has_logic' => true,
            'is_qualified' => empty($missing),
            'canonical_rank' => $canonicalRank,
            'missing' => $missing,
            'completed' => $completed
        ];
    }

    /**
     * Get names of all MOQs that have bypass enabled.
     *
     * @return string[]
     */
    public static function getBypassedMoqs(): array {
        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }
        $db = getDB();
        try {
            $cached = $db->query("SELECT name FROM moqs WHERE is_bypass = 1")->fetchAll(\PDO::FETCH_COLUMN) ?: [];
        } catch (\Throwable $e) {
            $cached = [];
        }
        return $cached;
    }

    /**
     * Get summary counts and personnel IDs grouped by promotion/MOQ qualification status.
     * Evaluates rank-based rules via checkPromotionStatus().
     *
     * @return array{qualified_count: int, not_qualified_count: int, qualified_ids: int[], not_qualified_ids: int[]}
     */
    public static function getPromotionQualificationCounts(): array {
        $db = getDB();
        $personnelRanks = $db->query("SELECT p.id, p.moq_na, r.name AS rank_name FROM personnel p JOIN ranks r ON p.rank_id = r.id")->fetchAll(\PDO::FETCH_ASSOC);
        $allMoqs = $db->query("SELECT pm.personnel_id, m.name AS moq_name, pm.result, pm.is_bypass FROM personnel_moqs pm JOIN moqs m ON pm.moq_id = m.id")->fetchAll(\PDO::FETCH_ASSOC);
        $allCourses = $db->query("SELECT pc.personnel_id, c.name AS course_name, pc.result FROM personnel_courses pc JOIN courses c ON pc.course_id = c.id")->fetchAll(\PDO::FETCH_ASSOC);
        $allCadres = $db->query("SELECT pc.personnel_id, c.name AS cadre_name FROM personnel_cadres pc JOIN cadres c ON pc.cadre_id = c.id")->fetchAll(\PDO::FETCH_ASSOC);
        $allEdus = $db->query("SELECT personnel_id, civil_education FROM personnel_education")->fetchAll(\PDO::FETCH_KEY_PAIR) ?: [];

        $personnelMoqMap = [];
        foreach ($allMoqs as $row) {
            $personnelMoqMap[$row['personnel_id']][] = $row;
        }
        $personnelCourseMap = [];
        foreach ($allCourses as $row) {
            $personnelCourseMap[$row['personnel_id']][] = $row;
        }
        $personnelCadreMap = [];
        foreach ($allCadres as $row) {
            $personnelCadreMap[$row['personnel_id']][] = $row;
        }

        $qualifiedCount = 0;
        $notQualifiedCount = 0;
        $naCount = 0;
        $qualifiedIds = [];
        $notQualifiedIds = [];
        $naIds = [];

        foreach ($personnelRanks as $p) {
            $pId = (int)$p['id'];
            $isMoqNa = !empty($p['moq_na']);
            if ($isMoqNa) {
                $naCount++;
                $naIds[] = $pId;
                continue;
            }

            $pMoqs = $personnelMoqMap[$pId] ?? [];
            $pCourses = $personnelCourseMap[$pId] ?? [];
            $pCadres = $personnelCadreMap[$pId] ?? [];
            $pEdu = $allEdus[$pId] ?? 'HSC';

            $status = self::checkPromotionStatus($p['rank_name'] ?? '', $pMoqs, $pCourses, $pCadres, false, $pEdu);
            if ($status['has_logic']) {
                if ($status['is_qualified']) {
                    $qualifiedCount++;
                    $qualifiedIds[] = $pId;
                } else {
                    $notQualifiedCount++;
                    $notQualifiedIds[] = $pId;
                }
            }
        }

        return [
            'qualified_count' => $qualifiedCount,
            'not_qualified_count' => $notQualifiedCount,
            'na_count' => $naCount,
            'qualified_ids' => $qualifiedIds,
            'not_qualified_ids' => $notQualifiedIds,
            'na_ids' => $naIds
        ];
    }

    /**
     * Get personnel IDs matching a given MOQ qualification status ('qualified', 'not_qualified', 'not_applicable').
     *
     * @param string $moqStatus
     * @return int[]
     */
    public static function getPersonnelIdsByMoqStatus(string $moqStatus): array {
        $summary = self::getPromotionQualificationCounts();
        if ($moqStatus === 'qualified') {
            return $summary['qualified_ids'];
        }
        if ($moqStatus === 'not_qualified') {
            return $summary['not_qualified_ids'];
        }
        if ($moqStatus === 'not_applicable' || $moqStatus === 'na') {
            return $summary['na_ids'];
        }
        return [];
    }

    /**
     * Get personnel IDs matching an individual MOQ and qualification status.
     * Evaluates whether each personnel has qualified for the specific MOQ, is not qualified (lacking/failed),
     * or whether the MOQ is not applicable to them.
     *
     * @param int $moqId
     * @param string $status 'qualified', 'not_qualified', 'not_applicable'/'na', or ''/'any'
     * @return int[]
     */
    public static function getPersonnelIdsByIndividualMoq(int $moqId, string $status = ''): array {
        if ($moqId <= 0) {
            return [];
        }

        $db = getDB();
        $stmt = $db->prepare("SELECT id, name, is_bypass FROM moqs WHERE id = ?");
        $stmt->execute([$moqId]);
        $targetMoq = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$targetMoq) {
            return [];
        }

        $targetMoqName = trim((string)$targetMoq['name']);
        $isGlobalBypass = !empty($targetMoq['is_bypass']);
        $normMoq = strtolower($targetMoqName);

        $targetPatterns = [$normMoq];
        $requiredRanks = [];
        $isCommando = false;
        $isClmOrJcoc = false;

        if ($normMoq === 'btt' || str_contains($normMoq, 'basic trade')) {
            $targetPatterns = array_merge($targetPatterns, ['btt', 'basic trade training']);
            $requiredRanks = ['sainik'];
        } elseif ($normMoq === 'arms commando' || $normMoq === 'services commando' || str_contains($normMoq, 'commando')) {
            if ($normMoq === 'arms commando') {
                $targetPatterns = ['arms commando', 'commando'];
            } elseif ($normMoq === 'services commando') {
                $targetPatterns = ['services commando', 'commando'];
            } else {
                $targetPatterns = ['arms commando', 'services commando', 'commando'];
            }
            $requiredRanks = ['sainik'];
            $isCommando = true;
        } elseif ($normMoq === 'bmr' || str_contains($normMoq, 'basic military')) {
            $targetPatterns = array_merge($targetPatterns, ['bmr', 'basic military refresher']);
            $requiredRanks = ['sainik'];
        } elseif ($normMoq === 'pe' || str_contains($normMoq, 'promotion exam') || str_contains($normMoq, 'physical efficiency')) {
            $targetPatterns = array_merge($targetPatterns, ['pe', 'promotion exam', 'promotion examination', 'physical efficiency']);
            $requiredRanks = ['sainik', 'lance corporal', 'corporal', 'sergeant', 'warrant officer'];
        } elseif ($normMoq === 'pc' || str_contains($normMoq, 'potential cadre')) {
            $targetPatterns = array_merge($targetPatterns, ['pc', 'potential cadre']);
            $requiredRanks = ['lance corporal'];
        } elseif ($normMoq === 'att' || str_contains($normMoq, 'advance trade') || str_contains($normMoq, 'advanced trade')) {
            $targetPatterns = array_merge($targetPatterns, ['att', 'advance trade training', 'advanced trade training']);
            $requiredRanks = ['corporal'];
        } elseif ($normMoq === 'ncoc' || str_contains($normMoq, 'non-commissioned') || str_contains($normMoq, 'nco')) {
            $targetPatterns = array_merge($targetPatterns, ['ncoc', 'non-commissioned officers course', 'non commissioned officers course', "nco's advanced", "nco’s advanced", 'nco advanced', 'ncos advanced']);
            $requiredRanks = ['sergeant'];
        } elseif ($normMoq === 'utility course' || $normMoq === 'utility') {
            $targetPatterns = array_merge($targetPatterns, ['utility course', 'utility']);
            $requiredRanks = ['sergeant'];
        } elseif ($normMoq === 'clm cadre' || $normMoq === 'clm') {
            $targetPatterns = array_merge($targetPatterns, ['clm cadre', 'clm']);
            $requiredRanks = ['warrant officer'];
            $isClmOrJcoc = true;
        } elseif ($normMoq === 'jcoc' || str_contains($normMoq, 'junior command')) {
            $targetPatterns = array_merge($targetPatterns, ['jcoc', 'junior command', 'junior commissioned']);
            $requiredRanks = ['warrant officer'];
            $isClmOrJcoc = true;
        }

        $personnel = $db->query("SELECT p.id, p.moq_na, r.name AS rank_name FROM personnel p JOIN ranks r ON p.rank_id = r.id")->fetchAll(\PDO::FETCH_ASSOC);
        $allMoqs = $db->query("SELECT pm.personnel_id, pm.moq_id, m.name AS moq_name, pm.result, pm.is_bypass FROM personnel_moqs pm JOIN moqs m ON pm.moq_id = m.id")->fetchAll(\PDO::FETCH_ASSOC);
        $allCourses = $db->query("SELECT pc.personnel_id, c.name AS course_name, pc.result FROM personnel_courses pc JOIN courses c ON pc.course_id = c.id")->fetchAll(\PDO::FETCH_ASSOC);
        $allCadres = $db->query("SELECT pc.personnel_id, c.name AS cadre_name FROM personnel_cadres pc JOIN cadres c ON pc.cadre_id = c.id")->fetchAll(\PDO::FETCH_ASSOC);

        $pMoqMap = [];
        foreach ($allMoqs as $row) {
            $pMoqMap[$row['personnel_id']][] = $row;
        }
        $pCourseMap = [];
        foreach ($allCourses as $row) {
            $pCourseMap[$row['personnel_id']][] = $row;
        }
        $pCadreMap = [];
        foreach ($allCadres as $row) {
            $pCadreMap[$row['personnel_id']][] = $row;
        }

        $isFailed = static function (?string $result): bool {
            if ($result === null) return false;
            $r = strtolower(trim($result));
            return in_array($r, ['fail', 'failed', 'f', 'unsuccessful', 'not qualified', 'disqualified', 'dropped'], true);
        };

        $qualifiedIds = [];
        $notQualifiedIds = [];
        $naIds = [];
        $hasRecordIds = [];

        foreach ($personnel as $p) {
            $pId = (int)$p['id'];
            $isMoqNa = !empty($p['moq_na']);
            $rawRank = strtolower(trim((string)$p['rank_name']));

            $canonicalRank = match (true) {
                in_array($rawRank, ['sainik', 'snk', 'snk(gd)', 'snk (gd)', 'soldier', 'snk.'], true) || str_starts_with($rawRank, 'snk') => 'sainik',
                in_array($rawRank, ['lance corporal', 'lcpl', 'l/cpl', 'l.cpl', 'l cpl', 'l-cpl'], true) || str_starts_with($rawRank, 'lcpl') || str_starts_with($rawRank, 'l/cpl') => 'lance corporal',
                in_array($rawRank, ['corporal', 'cpl', 'cpl.'], true) || str_starts_with($rawRank, 'cpl') => 'corporal',
                in_array($rawRank, ['sergeant', 'sgt', 'sgt.'], true) || str_starts_with($rawRank, 'sgt') => 'sergeant',
                in_array($rawRank, ['warrant officer', 'wo', 'wo.', 'swo', 'senior warrant officer', 'mwo', 'master warrant officer'], true) || $rawRank === 'wo' || str_starts_with($rawRank, 'wo ') || str_starts_with($rawRank, 'swo') || str_starts_with($rawRank, 'mwo') => 'warrant officer',
                default => null,
            };

            // Check if qualified
            $isQualified = false;
            if ($isGlobalBypass) {
                $isQualified = true;
            }

            $pMoqs = $pMoqMap[$pId] ?? [];
            $attemptedAndFailed = false;

            foreach ($pMoqs as $m) {
                if ((int)$m['moq_id'] === $moqId) {
                    $hasRecordIds[] = $pId;
                    $res = $m['result'] ?? null;
                    if (!empty($m['is_bypass']) || (is_string($res) && strtolower(trim($res)) === 'bypass')) {
                        $isQualified = true;
                        break;
                    }
                    if ($res !== null && trim((string)$res) !== '' && !$isFailed($res)) {
                        $isQualified = true;
                        break;
                    }
                    if ($isFailed($res) || $res === null || trim((string)$res) === '') {
                        $attemptedAndFailed = true;
                    }
                }
            }

            // Cross-table checks if not already qualified
            if (!$isQualified) {
                // Check courses
                foreach ($pCourseMap[$pId] ?? [] as $c) {
                    $cName = strtolower(trim((string)$c['course_name']));
                    $cRes = $c['result'] ?? null;
                    if (!$isFailed($cRes)) {
                        foreach ($targetPatterns as $pattern) {
                            if ($cName === $pattern || preg_match('/\b' . preg_quote($pattern, '/') . '\b/i', $cName) === 1) {
                                $isQualified = true;
                                break 2;
                            }
                        }
                    }
                }
                // Check cadres
                if (!$isQualified) {
                    foreach ($pCadreMap[$pId] ?? [] as $cd) {
                        $cdName = strtolower(trim((string)$cd['cadre_name']));
                        foreach ($targetPatterns as $pattern) {
                            if ($cdName === $pattern || preg_match('/\b' . preg_quote($pattern, '/') . '\b/i', $cdName) === 1) {
                                $isQualified = true;
                                break 2;
                            }
                        }
                    }
                }
                // SGT utility course equivalency: any valid non-NCOC course
                if (!$isQualified && $canonicalRank === 'sergeant' && ($normMoq === 'utility course' || $normMoq === 'utility')) {
                    foreach ($pCourseMap[$pId] ?? [] as $c) {
                        $cName = strtolower(trim((string)$c['course_name']));
                        $cRes = $c['result'] ?? null;
                        if (!$isFailed($cRes) && !str_contains($cName, 'ncoc')) {
                            $isQualified = true;
                            break;
                        }
                    }
                }
            }

            if ($isQualified) {
                $qualifiedIds[] = $pId;
            } else {
                // For promotion requirements with alternative options:
                // If Sainik has completed the other Commando course, they are not lacking Commando requirement
                $hasAlternativeCommando = false;
                if ($isCommando && $canonicalRank === 'sainik') {
                    foreach ($pMoqs as $m) {
                        $mName = strtolower(trim((string)$m['moq_name']));
                        $res = $m['result'] ?? null;
                        if ((str_contains($mName, 'commando')) && (!empty($m['is_bypass']) || ($res !== null && trim((string)$res) !== '' && !$isFailed($res)))) {
                            $hasAlternativeCommando = true;
                            break;
                        }
                    }
                }
                $hasAlternativeClm = false;
                if ($isClmOrJcoc && $canonicalRank === 'warrant officer') {
                    foreach ($pMoqs as $m) {
                        $mName = strtolower(trim((string)$m['moq_name']));
                        $res = $m['result'] ?? null;
                        if ((str_contains($mName, 'clm') || str_contains($mName, 'jcoc')) && (!empty($m['is_bypass']) || ($res !== null && trim((string)$res) !== '' && !$isFailed($res)))) {
                            $hasAlternativeClm = true;
                            break;
                        }
                    }
                }

                $isApplicableRank = ($canonicalRank !== null && (empty($requiredRanks) || in_array($canonicalRank, $requiredRanks, true)));
                if ($isMoqNa || $canonicalRank === null || $hasAlternativeCommando || $hasAlternativeClm || (!$isApplicableRank && !$attemptedAndFailed)) {
                    $naIds[] = $pId;
                } else {
                    $notQualifiedIds[] = $pId;
                }
            }
        }

        $statusLower = strtolower(trim($status));
        if ($statusLower === 'qualified') {
            return $qualifiedIds;
        }
        if ($statusLower === 'not_qualified') {
            return $notQualifiedIds;
        }
        if ($statusLower === 'not_applicable' || $statusLower === 'na') {
            return $naIds;
        }

        // 'any' or empty: return anyone who has a record in personnel_moqs for this moq_id OR is qualified
        return array_values(array_unique(array_merge($qualifiedIds, $hasRecordIds)));
    }

    /**
     * Get a map of personnel_id => array of missing MOQ names.
     * If $specificMoqId > 0, returns only that MOQ name for personnel who have not qualified in it.
     * Otherwise returns all missing promotion requirements for each personnel.
     *
     * @param int $specificMoqId
     * @return array<int, string[]>
     */
    public static function getMissingMoqsMap(int $specificMoqId = 0): array {
        $db = getDB();

        if ($specificMoqId > 0) {
            $notQualIds = self::getPersonnelIdsByIndividualMoq($specificMoqId, 'not_qualified');
            $moqName = $db->query("SELECT name FROM moqs WHERE id = " . (int)$specificMoqId)->fetchColumn() ?: 'MOQ';
            $map = [];
            foreach ($notQualIds as $id) {
                $map[(int)$id] = [$moqName];
            }
            return $map;
        }

        $personnelRanks = $db->query("SELECT p.id, p.moq_na, r.name AS rank_name FROM personnel p JOIN ranks r ON p.rank_id = r.id")->fetchAll(\PDO::FETCH_ASSOC);
        $allMoqs = $db->query("SELECT pm.personnel_id, m.name AS moq_name, pm.result, pm.is_bypass FROM personnel_moqs pm JOIN moqs m ON pm.moq_id = m.id")->fetchAll(\PDO::FETCH_ASSOC);
        $allCourses = $db->query("SELECT pc.personnel_id, c.name AS course_name, pc.result FROM personnel_courses pc JOIN courses c ON pc.course_id = c.id")->fetchAll(\PDO::FETCH_ASSOC);
        $allCadres = $db->query("SELECT pc.personnel_id, c.name AS cadre_name FROM personnel_cadres pc JOIN cadres c ON pc.cadre_id = c.id")->fetchAll(\PDO::FETCH_ASSOC);
        $allEdus = $db->query("SELECT personnel_id, civil_education FROM personnel_education")->fetchAll(\PDO::FETCH_KEY_PAIR) ?: [];

        $pMoqMap = [];
        foreach ($allMoqs as $row) {
            $pMoqMap[$row['personnel_id']][] = $row;
        }
        $pCourseMap = [];
        foreach ($allCourses as $row) {
            $pCourseMap[$row['personnel_id']][] = $row;
        }
        $pCadreMap = [];
        foreach ($allCadres as $row) {
            $pCadreMap[$row['personnel_id']][] = $row;
        }

        $map = [];
        foreach ($personnelRanks as $p) {
            $pId = (int)$p['id'];
            if (!empty($p['moq_na'])) {
                continue;
            }
            $pMoqs = $pMoqMap[$pId] ?? [];
            $pCourses = $pCourseMap[$pId] ?? [];
            $pCadres = $pCadreMap[$pId] ?? [];
            $pEdu = $allEdus[$pId] ?? 'HSC';

            $status = self::checkPromotionStatus($p['rank_name'] ?? '', $pMoqs, $pCourses, $pCadres, false, $pEdu);
            if ($status['has_logic'] && !$status['is_qualified'] && !empty($status['missing'])) {
                $map[$pId] = $status['missing'];
            }
        }

        return $map;
    }
}



